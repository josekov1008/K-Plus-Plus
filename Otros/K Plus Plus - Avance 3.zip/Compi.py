import sys
import ply.lex as lex
import ply.yacc as yacc
import dataMatches

#############################################################################################
#Definicion del lexico del lenguaje
#############################################################################################

#Lista de tokens posibles
reserved = {
   'if' : 'IF',
   'else' : 'ELSE',
   'while' : 'WHILE',
   'for' : 'FOR',
   'print' : 'PRINT',
   'input' : 'INPUT',
   'int' : 'TIPO_INT',
   'float' : 'TIPO_FLOAT',
   'char' : 'TIPO_CHAR',
   'string' : 'TIPO_STRING',
   'void' : 'TIPO_VOID',
   'main' : 'MAIN'
}

tokens = ['INT', 'STRING', 'CHAR', 'FLOAT', 'DELIMITADOR_CUADRADO',
          'DELIMITADOR_ABRIR', 'DELIMITADOR_CERRAR', 'SEPARADOR', 'OPERADOR_MD', 'OPERADOR_SR', 
          'OPERADOR_LOGICO', 'OPERADOR_ANDOR', 'IDENTIFICADOR', 
          'OPERADOR_ASIGNACION', 'FIN_LINEA', 'DELIMITADOR_LLAVES'] + list(reserved.values()) ##Checar que hacer con MAIN D:


t_ignore = ' \t\n'

#Identificadores y palabras reservadas
def t_IDENTIFICADOR(token):
    r'[a-zA-Z][a-zA-Z0-9]*'
    token.type = reserved.get(token.value,'IDENTIFICADOR')    # Se checa por palabras reservadas en la lista inicial
    return token

#Constantes
def t_FLOAT(token):
    r'[0-9]*\.[0-9]+'
    token.value = float(token.value);
    return token
def t_INT(token):
    r'[0-9]+'
    token.value = int(token.value);
    return token
def t_CHAR(token):
    r'\'[a-zA-Z]\'' ##Checar prioridades de regex
    return token
def t_STRING(token):
    r'"[A-Za-z0-9]+"'
    return token

#Operadores
def t_OPERADOR_SR(token):
    r'\+|\-'
    return token

def t_OPERADOR_MD(token):
    r'\*|/'
    return token

def t_OPERADOR_LOGICO(token):
    r'<>|==|<|>'
    return token

def t_OPERADOR_ANDOR(token):
    r'&|\|'
    return token

def t_OPERADOR_ASIGNACION(token):
    r'='
    return token

#Otros simbolos
def t_DELIMITADOR_CUADRADO(token):
    r'\[|\]'
    return token
    
def t_DELIMITADOR_ABRIR(token):
    r'\('
    return token

def t_DELIMITADOR_CERRAR(token):
    r'\)'
    return token

def t_DELIMITADOR_LLAVES(token):
    r'\{|\}'
    return token

def t_FIN_LINEA(token):
    r'\;'
    return token

def t_SEPARADOR(token):
    r'\,'
    return token

#Para segmentos de codigo hay que hacer una funcion
def t_error(t):
    print 'Error de sintaxis en entrada: Caracter Invalido ' + t.value[0]
    #errores = True
    sys.exit()
    return t

#############################################################################################
#Definicion de las reglas de la gramatica
#############################################################################################

procedures = { }
variables = { }
calledVars = []
calledProcs = []
scope = 'global'

def isCompatible(op1, op2, operator, message):
    #Ver si hay una manera de guardar valores, una pila tal vez? seria ejecutar?
    if dataMatches.getResultType(op1, op2, operator) == -1:
        print "Error! Tipos no compatibles en operacion de " + message
        sys.exit()
    else:
        return dataMatches.getResultType(op1, op2, operator) * 1000
        
#Programa
def p_programa(p):
    '''programa : programaX MAIN DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''
    
    #Se obtienen las variables declaradas
    mainVars = { }
    mainVars['main'] = p[4]
    variables.update(mainVars)
    
    #Se checan las variables restantes para ver si pertenecen al main o son globales
    for key in calledVars:
        if key in variables['main'] or key in variables['global']:
            calledVars.remove(key)
        else:
            print "Error! Variable no declarada: " + key
            sys.exit()
            
    for key in calledProcs:
        if key in procedures.keys():
            calledProcs.remove(key)
        else:
            print "Error! Funcion no declarada: " + key
            sys.exit()
            
            
    print "Programa Correcto!"
    
    ##Todo lo que sigue son debugs
    print "-----------\nDebug Messages!\n"
    print "Procedures:"
    print procedures #Debug para la tabla de funciones, eliminar
    print "\nVariables:"
    print variables
    print "\n"
    
#Variables globales y funciones
def p_programaX(p):
    '''programaX : tipo IDENTIFICADOR programaY programaX
                 | ''' #Epsilon
    if len(p) > 3:
        if p[3] is not None:
            if p[3].has_key('var'):
                del p[3]['var']
                for key in p[3]:
                    p[3][key] = p[1]
                
                tempVars = {p[2] : p[1]}
                tempVars.update(p[3])
                
                #Se checa si hay un scope global
                if variables.has_key('global'):
                    globales = variables['global']
                    globales.update(tempVars)
                    variables['global'] = globales
                else:
                    variables['global'] = tempVars
            
            #Si es funcion
            else:
                thisElement = { }
                thisElement['type'] = p[1]
 
                if p[3].has_key('localVars'):
                    if p[3]['localVars'] is not None:
                        localVars = p[3]['localVars'].copy()
                        del p[3]['localVars']
                        variables[p[2]] = localVars
                
                thisElement['params'] = p[3]
                procedures[p[2]] = thisElement
                scope = p[2]
                
                #Checar si las asignaciones existen en el scope o son argumentos actuales
                for key in calledVars:
                    if key in p[3].keys():
                        calledVars.remove(key)
                #Ambas comparaciones dentro de un mismo for no jalan... se soluciona usando dos fors! :D
                for key in calledVars:
                    if key in variables[scope].keys():
                        calledVars.remove(key)
                
                #Checar si es el nombre de alguna funcion, y de serlo, comparar argumentos (pendiente)
                for key in calledProcs:
                    if key in procedures.keys():
                        calledProcs.remove(key)
                        #Agregar aqui lo de los parametros

                      
def p_programaY(p):
    '''programaY : var
                 | funcion'''
    p[0] = p[1]

#Bloque Codigo
def p_bloqueCodigo(p):
    '''bloqueCodigo : estatuto bloqueCodigo
                    | ''' #Epsilon
    if len(p) > 2:
        if p[1] is not None:
            tempBloque = p[1]
            if p[2] is not None:
               tempBloque.update(p[2])

            p[0] = tempBloque
        else:
            if p[2] is not None:
                p[0] = p[2]

#Estatuto
def p_estatuto(p):
    '''estatuto : escritura
                | IDENTIFICADOR estatutoX
                | if
                | for
                | while
                | tipo IDENTIFICADOR var'''

    if len(p) > 3:
        #Declaraciones de variables
        if p[3] is not None:
            if p[3].has_key('var'):
                del p[3]['var']
                
                for key in p[3]:
                    p[3][key] = p[1]

                tempVars = {p[2] : p[1]}
                tempVars.update(p[3])
                p[0] = tempVars
    #Asignacion y llamada a funcion
    elif len(p) > 2:
        if p[2] == 103:
            calledVars.append(p[1])
        elif p[2] == 105:
            calledProcs.append(p[1])

#Temporales, no deberia quedarse asi (la primera regla esta mal, debuggear)... parece que ya quedo :D
def p_estatutoX(p):
    '''estatutoX : DELIMITADOR_ABRIR constanteY DELIMITADOR_CERRAR FIN_LINEA
                 | asignacionX OPERADOR_ASIGNACION estatutoY'''
    #Si es asignacion
    if p[1] != '(':
        p[0] = 103 #Codigo de asignacion
    else:
        p[0] = 105 #Codigo de llamada a funcion
        

def p_estatutoY(p):
    '''estatutoY : input
                 | asignacionY FIN_LINEA'''

#Funcion
def p_funcion(p):
    '''funcion : idFuncion DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''
    tempFunc = { }
    if p[1] is not None:
        tempFunc.update(p[1])
    if tempFunc is not None:
        tempFunc['localVars'] = p[3]
    p[0] = tempFunc
    
def p_idFuncion(p):
    '''idFuncion : DELIMITADOR_ABRIR idFuncionX DELIMITADOR_CERRAR'''
    p[0] = p[2]
    
def p_idFuncionX(p):
    '''idFuncionX : tipo IDENTIFICADOR idFuncionZ idFuncionY
                  | ''' #Epsilon
    if len(p) > 2:
        temp = {p[2] : p[1]}
        temp.update(p[4])
        p[0] = temp
    
def p_idFuncionY(p):
    '''idFuncionY : SEPARADOR idFuncionX
                  | ''' #Epsilon
    if len(p) > 2:
        p[0] = p[2]
    else:
        p[0] = { }

def p_idFuncionZ(p):
    '''idFuncionZ : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
                  | ''' #Epsilon
    
#Variables
def p_var(p):
    '''var : varX FIN_LINEA'''
    p[0] = p[1]
    
def p_varX(p):
    '''varX : varY varZ'''
    varsDict = { 'var' : 'var'}
    varsDict.update(p[2])
    p[0] = varsDict
    
def p_varY(p):
    '''varY : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
            | ''' #Epsilon
       
def p_varZ(p):
    '''varZ : SEPARADOR IDENTIFICADOR varX
            | ''' #Epsilon
    if len(p) > 3:
        tmpDir = { p[2] : 'var' }
        
        if p[3] is not None:
            if p[3].has_key('var'):
                del p[3]['var']
                temp = p[3]
                tmpDir.update(p[3])
        
        p[0] = tmpDir
    else:
        p[0] = { }
    
#Operacion
def p_operacion(p):
    '''operacion : expresion operacionX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            op2 = p[2] / 1000
            signo = 3
            op1 = p[1] / 1000

            p[0] = isCompatible(op1, op2, signo, "logica")
        else:
            p[0] = p[1]
    
def p_operacionX(p):
    '''operacionX : OPERADOR_ANDOR operacion
                  | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        p[0] = p[2]
                  
#Expresion
def p_expresion(p):
    '''expresion : exp expresionX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            
            if '>' in p[2].keys():
                signo = 4
                op2 = p[2]['>'] / 1000
            elif '<' in p[2].keys():
                signo = 4
                op2 = p[2]['<'] / 1000
            elif '==' in p[2].keys():
                signo = 5
                op2 = p[2]['=='] / 1000

            op1 = p[1] / 1000

            p[0] = isCompatible(op1, op2, signo, "comparacion de valores")
        else:
            p[0] = p[1]
    
def p_expresionX(p):
    '''expresionX : OPERADOR_LOGICO exp
                  | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        p[0] = {p[1] : p[2]}

#Factor
def p_factor(p):
    '''factor : DELIMITADOR_ABRIR expresion DELIMITADOR_CERRAR
              | constante
              | OPERADOR_SR constante'''
    if len(p) > 3:
        p[0] = p[2]
    elif len(p) > 2:
        if p[2] != 4000:
            p[0] = p[2]
        else:
            print "Error! Strings no soportados en signos"
            sys.exit()
    elif len(p) > 1:
        p[0] = p[1]

        

#Escritura
def p_escritura(p):
    '''escritura : PRINT DELIMITADOR_ABRIR operacion DELIMITADOR_CERRAR FIN_LINEA'''

#Asignacion
def p_asignacion(p):
    '''asignacion : IDENTIFICADOR asignacionX OPERADOR_ASIGNACION asignacionY FIN_LINEA'''
    
def p_asignacionX(p):
    '''asignacionX : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
                   | ''' #Epsilon

def p_asignacionY(p):
    '''asignacionY : operacion'''

#Exp
def p_exp(p):
    '''exp : termino expX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            op2 = p[2] / 1000
            signo = 1
            op1 = p[1] / 1000

            p[0] = isCompatible(op1, op2, signo, "suma/resta")
        else:
            p[0] = p[1]
    
def p_expX(p):
    '''expX : OPERADOR_SR exp
            | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        p[0] = p[2]
            
#Termino
def p_termino(p):
    '''termino : factor terminoX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            op2 = p[2] / 1000
            signo = 2
            op1 = p[1] / 1000
            
            p[0] = isCompatible(op1, op2, signo, "multiplicacion/division")
            
            #print p[1], signo, p[2]
            
            #Ver si hay una manera de guardar valores, una pila tal vez? seria ejecutar?
            #if dataMatches.getResultType(op1, op2, signo) == -1:
             #   print "Error! Tipos no compatibles en operacion de multiplicacion/division"
              #  sys.exit()
            #else:
             #   p[0] = dataMatches.getResultType(op1, op2, signo) * 1000
        else:
            p[0] = p[1]
    
def p_terminoX(p):
    '''terminoX : OPERADOR_MD termino
                | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        p[0] = p[2]
                
#For
def p_for(p):
    '''for : FOR DELIMITADOR_ABRIR asignacion operacion FIN_LINEA forX DELIMITADOR_CERRAR DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''

def p_forX(p):
    '''forX : IDENTIFICADOR forY'''

def p_forY(p):
    '''forY : asignacionX OPERADOR_ASIGNACION asignacionY
            | OPERADOR_SR exp'''

#While
def p_while(p):
    '''while : WHILE DELIMITADOR_ABRIR operacion DELIMITADOR_CERRAR DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''
    
#If
def p_if(p):
    '''if : IF DELIMITADOR_ABRIR operacion DELIMITADOR_CERRAR DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES ifX'''
    
def p_ifX(p):
    '''ifX : ELSE DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES
           | ''' #Epsilon

#Input
def p_input(p):
    '''input : INPUT DELIMITADOR_ABRIR tipo DELIMITADOR_CERRAR FIN_LINEA'''

#Constante
def p_constante(p):
    '''constante : cteString
                 | cteChar
                 | cteInt
                 | cteFloat
                 | cteId'''
    if len(p) > 1 and p[1] is not None:
        p[0] = p[1]

def p_cteInt(p):
    '''cteInt : INT'''
    p[0] = 1000
    
def p_cteChar(p):
    '''cteChar : CHAR'''
    p[0] = 3000

def p_cteString(p):
    '''cteString : STRING'''
    p[0] = 4000
    
def p_cteFloat(p):
    '''cteFloat : FLOAT'''
    p[0] = 2000
    
def p_cteId(p):
    '''cteId : IDENTIFICADOR constanteX'''
    #Pendiente ver que hacer con esto
                 
def p_constanteX(p):
    '''constanteX : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
                  | DELIMITADOR_ABRIR constanteY DELIMITADOR_CERRAR
                  | ''' #Epsilon

def p_constanteY(p):
    '''constanteY : constante constanteZ
                  | ''' #Epsilon
                  
def p_constanteZ(p):
    '''constanteZ : SEPARADOR constanteY
                  | ''' #Epsilon
                            
#Tipo
def p_tipo(p):
    '''tipo : TIPO_STRING
            | TIPO_CHAR
            | TIPO_INT
            | TIPO_FLOAT
            | TIPO_VOID'''
    p[0] = p[1]

#Funcion de error para el parser
def p_error(p):
    print "Error al parsear el programa. Mensaje: ", p
    sys.exit()
    return p

#Inicializacion del Lexer
lex.lex()

#Debug para cuando las reglas no funcionan bien D:
#Entrada
##lex.input("print (kovamasmas);")

#Uso de los tokens (imprimiendo por lo pronto)
##while True:
##    tok = lex.token()
##    if not tok:
##        break
##    else:
##        print tok.type

#Inicializacion del Parser
yacc.yacc()

nombreArchivo = raw_input("Nombre del Archivo: ")

archivo = open(nombreArchivo, 'r')

datos = archivo.read()

yacc.parse(datos)