import sys
import ply.lex as lex
import ply.yacc as yacc
import dataMatches

#############################################################################################
#Definicion del lexico del lenguaje
#############################################################################################

#Lista de tokens posibles
reserved = {
   'if' : 'IF',
   'else' : 'ELSE',
   'while' : 'WHILE',
   'for' : 'FOR',
   'return' : 'RETURN',
   'print' : 'PRINT',
   'input' : 'INPUT',
   'int' : 'TIPO_INT',
   'float' : 'TIPO_FLOAT',
   'char' : 'TIPO_CHAR',
   'string' : 'TIPO_STRING',
   'void' : 'TIPO_VOID',
   'main' : 'MAIN'
}

tokens = ['INT', 'STRING', 'CHAR', 'FLOAT', 'DELIMITADOR_CUADRADO',
          'DELIMITADOR_ABRIR', 'DELIMITADOR_CERRAR', 'SEPARADOR', 'OPERADOR_MD', 'OPERADOR_SR', 
          'OPERADOR_LOGICO', 'OPERADOR_ANDOR', 'IDENTIFICADOR', 
          'OPERADOR_ASIGNACION', 'FIN_LINEA', 'DELIMITADOR_LLAVES'] + list(reserved.values()) ##Checar que hacer con MAIN D:


t_ignore = ' \t\n'

#Identificadores y palabras reservadas
def t_IDENTIFICADOR(token):
    r'[a-zA-Z][a-zA-Z0-9]*'
    token.type = reserved.get(token.value,'IDENTIFICADOR')    # Se checa por palabras reservadas en la lista inicial
    return token

#Constantes
def t_FLOAT(token):
    r'[0-9]*\.[0-9]+'
    token.value = float(token.value)
    return token
def t_INT(token):
    r'[0-9]+'
    token.value = int(token.value)
    return token
def t_CHAR(token):
    r'\'[a-zA-Z0-9]\'' ##Checar prioridades de regex
    return token
def t_STRING(token):
    r'"[A-Za-z0-9]+"'
    return token

#Operadores
def t_OPERADOR_SR(token):
    r'\+|\-'
    return token

def t_OPERADOR_MD(token):
    r'\*|/'
    return token

def t_OPERADOR_LOGICO(token):
    r'<>|==|<|>'
    return token

def t_OPERADOR_ANDOR(token):
    r'&|\|'
    return token

def t_OPERADOR_ASIGNACION(token):
    r'='
    return token

#Otros simbolos
def t_DELIMITADOR_CUADRADO(token):
    r'\[|\]'
    return token
    
def t_DELIMITADOR_ABRIR(token):
    r'\('
    return token

def t_DELIMITADOR_CERRAR(token):
    r'\)'
    return token

def t_DELIMITADOR_LLAVES(token):
    r'\{|\}'
    return token

def t_FIN_LINEA(token):
    r'\;'
    return token

def t_SEPARADOR(token):
    r'\,'
    return token

#Para segmentos de codigo hay que hacer una funcion
def t_error(t):
    print 'Error de sintaxis en entrada: Caracter Invalido ', t.value[0]
    #errores = True
    sys.exit()
    return t

#############################################################################################
#Definicion de las reglas de la gramatica
#############################################################################################
#Contadores de direcciones virtuales
dirInt = 0
dirFloat = 1000
dirChar = 2000
dirString = 3000

#Tablas de variables y procs
procedures = { }
variables = { }

#Usados para identificacion de declaraciones y de tipos
calledVars = []
calledProcs = { }

#Usaro para identificacion de variables no declaradas en metodos
undeclaredVars = []
undeclaredProcs = []

#Generacion de cuadruplos
bufferCuadruplos = []
cuadruplos = []
contTemp = 1 #Esto no se debe quedar asi
bufferMD = []
bufferSR = []
bufferLogico = []
bufferANDOR = []
cuadruploActual = 0
bufferCondiciones = []
pSaltos = []

#Para llevar track del scope
scope = ''

#Encapsula el proceso de verificar si existe la variable en el scope
#Checa en el scope local dado y en el scope global
def isDeclared(var, scope):
    if var[0] in variables[scope]:
        type1 = getTypeVariable(variables[scope][var[0]])
        type2 = opsToType(var[1], scope)
            
        if isCompatible(type1 / 1000, type2 / 1000, 6, "asignacion"):
            return True
                
    elif 'global' in variables.keys():
        if var[0] in variables['global']:
            type1 = getTypeVariable(variables['global'][var[0]])
            type2 = opsToType(var[1], 'global')
                
            if isCompatible(type1 / 1000, type2 / 1000, 6, "asignacion"):
                return True
        else:
            return False
            
            
#Funcion para consultar el cubo de tipos
def isCompatible(op1, op2, operator, message):
    #Ver si hay una manera de guardar valores, una pila tal vez? seria ejecutar?
    if dataMatches.getResultType(op1, op2, operator) == -1:
        print "Error! Tipos no compatibles en operacion de", message
        sys.exit()
    else:
        return dataMatches.getResultType(op1, op2, operator) * 1000

#Funcion para asignar una direccion en base al tipo de asignacion        
def assignAddress(tipo):
    if tipo == 'int':
        global dirInt
        dirInt += 1
        return dirInt - 1
    elif tipo == 'float':
        global dirFloat
        dirFloat += 1
        return dirFloat - 1
    elif tipo == 'char':
        global dirChar
        dirChar += 1
        return dirChar - 1
    else:
        global dirString
        dirString += 1
        return dirString - 1
 
#Obtener identificador de tipo (numerico) a base de la direccion     
def getTypeVariable(address):
    if address < 1000:
        return 1000
    elif address >= 1000 and address < 2000:
        return 2000
    elif address >= 2000 and address < 3000:
        return 3000
    else:
        return 4000
      
#Se obtiene el tipo a base del id
def getTypeName(tipoId):
    if tipoId == 1000:
        return 'int'
    elif tipoId == 2000:
        return 'float'
    elif tipoId == 3000:
        return 'char'
    elif tipoId == 4000:
        return 'string'
    else:
        return 'void'
      
#Se obtienen las claves para cada tipo           
def getTypeId(tipo):
    if tipo == 'int':
        return 1000
    elif tipo == 'float':
        return 2000
    elif tipo == 'char':
        return 3000
    elif tipo == 'string':
        return 4000
    elif tipo == 'void':
        return 5000
        
#Interpretar los dicts que contienen los ordenes de operaciones
def opsToType(d, scope):
    #Si ya es un tipo
    if isinstance(d, int):
        return d
    #Si es una lista de operaciones
    elif isinstance(d, list):
        print d
    #Si hay otra variable de por medio
    elif isinstance(d, dict):
        var1 = d.keys()[0]
        
        if var1 in variables[scope].keys():
            type1 = getTypeVariable(variables[scope][var1])
            return opsToTypeAux(d[var1], type1, scope)
        #Es funcion si tiene el 9999 en la llamada
        elif var1 in procedures.keys() and d[var1].has_key(9999):
            #Se verifican los argumentos con los llamados
            if d[var1][9999] is not None:
                argsCalled = d[var1][9999]
                funcArgs = list(procedures[var1]['params'].values())

                if len(argsCalled) != len(funcArgs):
                    print "Error! cantidad de argumentos en funcion", var1
                    sys.exit()
                
                for arg in argsCalled:
                    for param in procedures[var1]['params'].values():
                        if isCompatible(arg / 1000, getTypeVariable(param) / 1000, 6, "asignacion"):
                            funcArgs.remove(param)

                if len(funcArgs) == 0:
                    return procedures[var1]['type']
                else:
                    print "Error! Inconsistencia de argumentos en funcion", var1
                    sys.exit()
            else:
                #Checar que no se esperen argumentos y estos no vengan en la llamada
                
                if len(procedures[var1]['params'].keys()) == 0:
                    return procedures[var1]['type']
                else:
                    print "Error! Argumentos esperados para funcion",  var1
                    sys.exit()
        else:
            print "Error! variable/funcion no declarada", var1
            sys.exit()

#Se analiza la lista de tuplas que contiene operaciones
def opsToTypeAux(listaOps, tipoInicial, scope):
    tipo1 = tipoInicial
    
    for op in listaOps:
        operacion = op[0]
        
        if isinstance(op[1], dict):
            tipo2 = opsToType(op[1], scope)
        else:
            tipo2 = op[1]

        tipo1 = isCompatible(tipo1 / 1000, tipo2 / 1000, operacion, "asignacion")
    
    return tipo1

#Se crean los cuadruplos como tuplas de python
def makeCuadruple(signo):
    global bufferCuadruplos
    global contTemp
    global cuadruploActual
    #Se ve si hay cosas en le buffer de cuads
    if len(bufferCuadruplos) > 0:
        op1 = bufferCuadruplos.pop()
        
        #Si solo habia una hay que buscar en los temporales (pendiente)
        #Operaciones que requieren dos
        #if len(bufferCuadruplos) > 2:
        temp = "T" + str(contTemp)
        
        opr = signo.pop()
        
        #print "\nOPR", opr, "\n"
        #A la hora de asignar un cuad, validar si tiene resultado, y asignar temporal para guardarlo
        #Asignaciones
        if opr == "=":
            if len(bufferCuadruplos) > 0:
                op2 = bufferCuadruplos.pop()
                cuad = [opr, op2, op1]
        #Estatutos de impresion
        elif opr == "print":
            cuad = [opr, op1]
        #Estatutos de entrada
        elif opr == "input":
            cuad = [opr, op1, temp]
            bufferCuadruplos.append(temp)
            contTemp += 1
        #Salto en falso
        elif opr == "gotoF":
#            print "buffer before goto", bufferCuadruplos
            place = bufferCondiciones.pop()
            cuad = [opr, op1, "---"]
            cuadruplos.insert(place, cuad)
            pSaltos.append(place)
            print "Debug  saltos", pSaltos
            cuadruploActual += 1
            return
        #Default: Operaciones matematicas
        else:
            if len(bufferCuadruplos) > 0:
                op2 = bufferCuadruplos.pop()
                cuad = [opr, op2, op1, temp]
                bufferCuadruplos.append(temp)
                contTemp += 1
            
        cuadruplos.append(cuad)
        cuadruploActual += 1

def completeCuad():
    if len(pSaltos) > 0:
        indPend = pSaltos.pop()
        pend = cuadruplos[14]
        print "Pend", pend

#Programa
def p_programa(p):
    '''programa : programaX MAIN DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''
    
    #Se obtienen las variables declaradas
    mainVars = { }
    if p[4] is not None and p[4].has_key('tempVars'):
        mainVars['main'] = p[4]['tempVars']
    
    variables.update(mainVars)
  
    #Variables llamadas en el scope
    scope = 'main'
    if p[4].has_key('call'):
        #Si existe el scope, se busca ahi y en lo global
        if scope in variables.keys():
            for key in list(p[4]['call']):
                if isDeclared(key, scope):
                    p[4]['call'].remove(key)
                            
        #Si sobro alguna esta de mas            
        if len(p[4]['call']) > 0:
            print "Error! Variable no declarada", key[0], "en el scope", scope
            sys.exit()

            
    for key in list(calledProcs.keys()):
        if key in procedures.keys() and procedures[key]['type'] == calledProcs[key]:
            del calledProcs[key]
        else:
            print "Error! Funcion no declarada:", key, "de tipo:", getTypeName(calledProcs[key]) 
            sys.exit() 
    
    print "Debug Cuads", cuadruplos
    
    print "Programa Correcto!"
    
    ##Todo lo que sigue son debugs
    print "-----------\nDebug Messages!\n"
    print "Procedures:"
    print procedures #Debug para la tabla de funciones, eliminar
    print "\nVariables:"
    print variables
    print "\n"
    
#Variables globales y funciones
def p_programaX(p):
    '''programaX : tipo IDENTIFICADOR programaY programaX
                 | ''' #Epsilon
    if len(p) > 3:
        if p[3] is not None:
            if p[3].has_key('var'):
                del p[3]['var']
                
                dirDato = assignAddress(p[1])
                
                for key in p[3]:
                    p[3][key] = dirDato
                
                tempVars = {p[2] : dirDato}
                tempVars.update(p[3])
                
                #Se checa si hay un scope global
                if variables.has_key('global'):
                    globales = variables['global']
                    globales.update(tempVars)
                    variables['global'] = globales
                else:
                    variables['global'] = tempVars
            
            #Si es funcion
            else:
                thisElement = { }
                thisElement['type'] = getTypeId(p[1])
 
                if p[3].has_key('localVars'):
                    if p[3]['localVars'] is not None:
                        localVars = p[3]['localVars'].copy()
                        del p[3]['localVars']
                        variables[p[2]] = localVars
                
                if p[3].has_key('params'):
                    thisElement['params'] = p[3]['params']
                else:
                    thisElement['params'] = { }
                
                procedures[p[2]] = thisElement
                
                scope = p[2]
                
                #Variables llamadas en el scope
                if p[3].has_key('calledVars'):
                    #Si existe el scope, se busca ahi y en lo global
                    if scope in variables.keys():
                        for key in list(p[3]['calledVars']):
                            if isDeclared(key, scope):
                                p[3]['calledVars'].remove(key)
                    
                    #Se busca ahora en los parametros
                    if thisElement.has_key('params'):
                        if len(thisElement['params']) > 0:
                            for key in list(p[3]['calledVars']):                      
                                if key[0] in thisElement['params'].keys() and isCompatible(opsToType(key[1], scope) / 1000, getTypeVariable(p[3]['params'][key[0]]) / 1000, 6, "asignacion"):
                                    p[3]['calledVars'].remove(key)
                                        
                    #Si sobro alguna esta de mas            
                    if len(p[3]['calledVars']) > 0:
                        print "Error! Variable no declarada", key[0], "en el scope", scope
                        sys.exit()
                      
def p_programaY(p):
    '''programaY : var
                 | funcion'''
    p[0] = p[1]

#Bloque Codigo
def p_bloqueCodigo(p):
    '''bloqueCodigo : estatuto bloqueCodigo
                    | ''' #Epsilon
    
    if len(p) > 2:
        if p[1] is not None:
            tempBloque = p[1]
            if p[2] is not None:
               bloqueCodigo = {}
               if tempBloque.has_key('call') and p[2].has_key('call'):
                   listaTemp = tempBloque['call']
                   for call in p[2]['call']:
                       if call not in tempBloque['call']:
                           listaTemp.append(call)
                   tempBloque['call'] = listaTemp
                   del p[2]['call']
               else:
                   if p[2].has_key('call'):
                       tempBloque['call'] = p[2]['call']

               if tempBloque.has_key('tempVars') and p[2].has_key('tempVars'):
                   tempv1 = tempBloque['tempVars']
                   tempv2 = p[2]['tempVars']
                   tempv1.update(tempv2)
                   tempBloque['tempVars'] = tempv1
               else:
                   if p[2].has_key('tempVars'):
                       tempBloque['tempVars'] = p[2]['tempVars']
            
            p[0] = tempBloque
        else:
            if p[2] is not None:
                p[0] = p[2]

#Estatuto
def p_estatuto(p):
    '''estatuto : escritura
                | IDENTIFICADOR estatutoX
                | if
                | for
                | while
                | tipo IDENTIFICADOR var
                | RETURN constante'''

    if len(p) > 3 and p[1] is not 'return':
        #Declaraciones de variables
        if p[3] is not None:
            if p[3].has_key('var'):
                
                del p[3]['var']
                
                
                for key in p[3]:
                    p[3][key] = assignAddress(p[1])

                tempVars = {p[2] : assignAddress(p[1])}
                tempVars.update(p[3])
                
                p[0] = {'tempVars' : tempVars}
    #Asignacion y llamada a funcion
    elif len(p) > 2:
        if p[2].has_key(103):
            res = p[2][103]
            
            bufferCuadruplos.append(p[1])
            makeCuadruple(["="])
            
            p[0] = {'call':[(p[1], res)]}
        elif p[2].has_key(105):
            if p[1] not in calledProcs.keys():
                calledProcs[p[1]] = p[2][105]

    elif len(p) > 1 and p[1] is not None:
        if p[1] == 106:
            makeCuadruple(["gotoF"])

#Temporales, no deberia quedarse asi (la primera regla esta mal, debuggear)... parece que ya quedo :D
def p_estatutoX(p):
    '''estatutoX : DELIMITADOR_ABRIR constanteY DELIMITADOR_CERRAR FIN_LINEA
                 | asignacionX OPERADOR_ASIGNACION estatutoY'''
    #Si es asignacion
    if p[1] != '(':
        p[0] = {103 : p[3]} #Codigo de asignacion
    else:
        p[0] = {105 : 5000} #Codigo de llamada a funcion, solo podrian ser voids
        

def p_estatutoY(p):
    '''estatutoY : input
                 | asignacionY FIN_LINEA'''

    p[0] = p[1]

#Funcion
def p_funcion(p):
    '''funcion : idFuncion DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''
    tempFunc = { }
    if p[1] is not None:
        tempFunc['params'] = p[1]
    if tempFunc is not None and p[3] is not None:
        if p[3].has_key('tempVars'):
            tempFunc['localVars'] = p[3]['tempVars']
        
        if p[3].has_key('call'):
            tempFunc['calledVars'] = p[3]['call']
 
    p[0] = tempFunc
    
def p_idFuncion(p):
    '''idFuncion : DELIMITADOR_ABRIR idFuncionX DELIMITADOR_CERRAR'''
    p[0] = p[2]
    
def p_idFuncionX(p):
    '''idFuncionX : tipo IDENTIFICADOR idFuncionZ idFuncionY
                  | ''' #Epsilon
    if len(p) > 2:
        temp = {p[2] : assignAddress(p[1])}
        temp.update(p[4])
        p[0] = temp
    
def p_idFuncionY(p):
    '''idFuncionY : SEPARADOR idFuncionX
                  | ''' #Epsilon
    if len(p) > 2:
        p[0] = p[2]
    else:
        p[0] = { }

def p_idFuncionZ(p):
    '''idFuncionZ : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
                  | ''' #Epsilon
    
#Variables
def p_var(p):
    '''var : varX FIN_LINEA'''
    p[0] = p[1]
    
def p_varX(p):
    '''varX : varY varZ'''
    varsDict = { 'var' : 'var'}
    varsDict.update(p[2])
    p[0] = varsDict
    
def p_varY(p):
    '''varY : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
            | ''' #Epsilon
       
def p_varZ(p):
    '''varZ : SEPARADOR IDENTIFICADOR varX
            | ''' #Epsilon
    if len(p) > 3:
        tmpDir = { p[2] : 'var' }
        
        if p[3] is not None:
            if p[3].has_key('var'):
                del p[3]['var']
                temp = p[3]
                tmpDir.update(p[3])
        
        p[0] = tmpDir
    else:
        p[0] = { }
    
#Operacion
def p_operacion(p):
    '''operacion : expresion operacionX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            #Si es dict es porque es variable, se trata diferente
            if isinstance(p[1], dict):
                idVar = p[1].keys()[0]
                ops = p[1].values()[0]
   
                if isinstance(ops, dict) and ops.has_key(9999):
                    p[0] = p[1]
                else:
                    ops.append( (3, p[2]) )
                    p[0] = {idVar : ops}
                
            else:
                makeCuadruple(bufferANDOR)
                bufferCondiciones.append(cuadruploActual)
                op2 = p[2] / 1000
                signo = 3
                op1 = p[1] / 1000      
    
                p[0] = isCompatible(op1, op2, signo, "logica")
        else:
            p[0] = p[1]
    
def p_operacionX(p):
    '''operacionX : OPERADOR_ANDOR operacion
                  | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        bufferANDOR.append(p[1])
        p[0] = p[2]
                  
#Expresion
def p_expresion(p):
    '''expresion : exp expresionX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            #Si es dict es porque es variable, se trata diferente
            if isinstance(p[1], dict):
                idVar = p[1].keys()[0]
                ops = p[1].values()[0]
                
                if isinstance(ops, dict) and ops.has_key(9999):
                    p[0] = p[1]
                else:
                
                    if '>' in p[2].keys():
                        ops.append( (4, p[2]) )
                    elif '<' in p[2].keys():
                        ops.append( (4, p[2]) )
                    elif '==' in p[2].keys():
                        ops.append( (5, p[2]) )
                               
                    p[0] = {idVar : ops}
            else:
                makeCuadruple(bufferLogico)
                
                if '>' in p[2].keys():
                    signo = 4
                    op2 = p[2]['>'] / 1000
                elif '<' in p[2].keys():
                    signo = 4
                    op2 = p[2]['<'] / 1000
                elif '==' in p[2].keys():
                    signo = 5
                    op2 = p[2]['=='] / 1000
    
                bufferCondiciones.append(cuadruploActual)
    
                op1 = p[1] / 1000
    
                p[0] = isCompatible(op1, op2, signo, "comparacion de valores")
        else:
            p[0] = p[1]
    
def p_expresionX(p):
    '''expresionX : OPERADOR_LOGICO exp
                  | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        bufferLogico.append(p[1])
        p[0] = {p[1] : p[2]}

#Factor
def p_factor(p):
    '''factor : DELIMITADOR_ABRIR expresion DELIMITADOR_CERRAR
              | constante
              | OPERADOR_SR constante'''
    if len(p) > 3:
        p[0] = p[2]
    elif len(p) > 2:
        if p[2] != 4000:
            
            #Generacion de cuadruplos
            global bufferCuadruplos
            bufferCuadruplos.insert(len(bufferCuadruplos) - 1, 0)
            makeCuadruple(["-"])
            
            p[0] = p[2]
        else:
            print "Error! Strings no soportados en signos"
            sys.exit()
    elif len(p) > 1:
        p[0] = p[1]

#Escritura
def p_escritura(p):
    '''escritura : PRINT DELIMITADOR_ABRIR operacion DELIMITADOR_CERRAR FIN_LINEA'''
    #bufferCuadruplos.append(p[3])
    makeCuadruple(["print"])

#Asignacion
def p_asignacion(p):
    '''asignacion : IDENTIFICADOR asignacionX OPERADOR_ASIGNACION asignacionY FIN_LINEA'''
    
def p_asignacionX(p):
    '''asignacionX : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
                   | ''' #Epsilon

def p_asignacionY(p):
    '''asignacionY : operacion'''
    p[0] = p[1]

#Exp
def p_exp(p):
    '''exp : termino expX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            #Si es dict es porque es variable, se trata diferente
            if isinstance(p[1], dict):
                idVar = p[1].keys()[0]
                ops = p[1].values()[0]
                
                if isinstance(ops, dict) and ops.has_key(9999):
                    p[0] = p[1]
                else:
                    ops.append( (1, p[2]) )
                    p[0] = {idVar : ops}
                
            else:
                makeCuadruple(bufferSR)
                
                op2 = p[2] / 1000
                signo = 1
                op1 = p[1] / 1000
    
                p[0] = isCompatible(op1, op2, signo, "suma/resta")
        else:
            p[0] = p[1]
    
def p_expX(p):
    '''expX : OPERADOR_SR exp
            | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        bufferSR.append(p[1])
        #cuadruplos.append(p[1]) #Prueba de cuadruplos
        p[0] = p[2]
            
#Termino
def p_termino(p):
    '''termino : factor terminoX'''
    if len(p) > 2:
        #Si son dos o mas operandos, se verifica que sean compatibles
        if p[2] is not None:
            #Si es dict es porque es variable, se trata diferente
            if isinstance(p[1], dict):
                idVar = p[1].keys()[0]
                ops = p[1].values()[0]
                
                if isinstance(ops, dict) and ops.has_key(9999):
                    p[0] = p[1]
                else:
                    ops.append( (2, p[2]) )
                    p[0] = {idVar : ops}
                
            else:
                
                makeCuadruple(bufferMD)
                
                op2 = p[2] / 1000
                signo = 2
                op1 = p[1] / 1000
                
                p[0] = isCompatible(op1, op2, signo, "multiplicacion/division")
        else:
            #makeCuadruple(bufferMD)
            p[0] = p[1]
    
def p_terminoX(p):
    '''terminoX : OPERADOR_MD termino
                | ''' #Epsilon
    if len(p) > 2 and p[2] is not None:
        bufferMD.append(p[1])
        
        p[0] = p[2]
                
#For
def p_for(p):
    '''for : FOR DELIMITADOR_ABRIR asignacion operacion FIN_LINEA forX DELIMITADOR_CERRAR DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''

def p_forX(p):
    '''forX : IDENTIFICADOR forY'''

def p_forY(p):
    '''forY : asignacionX OPERADOR_ASIGNACION asignacionY
            | OPERADOR_SR exp'''

#While
def p_while(p):
    '''while : WHILE DELIMITADOR_ABRIR operacion DELIMITADOR_CERRAR DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES'''
    
#If
def p_if(p):
    '''if : IF DELIMITADOR_ABRIR operacion DELIMITADOR_CERRAR DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES ifX'''
    if p[8] is None:
        print "If end", cuadruploActual
        p[0] = 106
    
def p_ifX(p):
    '''ifX : ELSE DELIMITADOR_LLAVES bloqueCodigo DELIMITADOR_LLAVES
           | ''' #Epsilon
    if len(p) > 1:
        p[0] = 107

#Input
def p_input(p):
    '''input : INPUT DELIMITADOR_ABRIR tipo DELIMITADOR_CERRAR FIN_LINEA'''
    bufferCuadruplos.append(p[3])
    makeCuadruple(["input"])
    p[0] = getTypeId(p[3])

#Constante
def p_constante(p):
    '''constante : cteString
                 | cteChar
                 | cteInt
                 | cteFloat
                 | cteId'''
    if len(p) > 1 and p[1] is not None:
        p[0] = p[1]

def p_cteInt(p):
    '''cteInt : INT'''
    bufferCuadruplos.append(p[1])
    p[0] = 1000
    
def p_cteChar(p):
    '''cteChar : CHAR'''
    bufferCuadruplos.append(p[1])
    p[0] = 3000

def p_cteString(p):
    '''cteString : STRING'''
    bufferCuadruplos.append(p[1])
    p[0] = 4000
    
def p_cteFloat(p):
    '''cteFloat : FLOAT'''
    bufferCuadruplos.append(p[1])
    p[0] = 2000
    
def p_cteId(p):
    '''cteId : IDENTIFICADOR constanteX'''
    #Pendiente ver que hacer con esto
    #Checar si esta declarada y el tipo, regresar acorde
    if len(p) > 2:
        bufferCuadruplos.append(p[1])
        if p[2] is not None:
            if p[2].has_key('func'):
                #Modficar esto para que lo trate como las variables y al final buscar en la tabla.... malditas reglas recursivas
                #(Pendiente)
                '''if procedures.has_key(p[1]):
                    #Se regresa el tipo adecuado
                    p[0] = procedures[p[1]]['type']
                else:'''
                    #Puede que el proceso no este aun en la tabla (recursividad de las reglas)
                #print "args in call", p[2] #Reemplazar los 9999 con esto? :o
                #print "test argos", len([])
                dato = p[2]['func']
                p[0] = { p[1] : {9999  : dato} }
        else:
            #Regresar el tipo de variable (pendiente)
            #Tomar en cuenta si son 2 variables haciendo una operacion D:
            p[0] = {p[1] : []}
                             
def p_constanteX(p):
    '''constanteX : DELIMITADOR_CUADRADO exp DELIMITADOR_CUADRADO
                  | DELIMITADOR_ABRIR constanteY DELIMITADOR_CERRAR
                  | ''' #Epsilon
    if len(p) > 2:
        if p[1] == '(':
            p[0] = { 'func':p[2] }
        

def p_constanteY(p):
    '''constanteY : constante constanteZ
                  | ''' #Epsilon
    if len(p) > 2:
        args = [p[1]]
        if p[2] is not None:
            args = args + p[2]
            
        p[0] = args
                  
def p_constanteZ(p):
    '''constanteZ : SEPARADOR constanteY
                  | ''' #Epsilon
    if len(p) > 2:
        p[0] = p[2]
    
#Tipo
def p_tipo(p):
    '''tipo : TIPO_STRING
            | TIPO_CHAR
            | TIPO_INT
            | TIPO_FLOAT
            | TIPO_VOID'''
    p[0] = p[1]

#Funcion de error para el parser
def p_error(p):
    print "Error al parsear el programa. Mensaje: ", p
    sys.exit()
    return p

#Inicializacion del Lexer
lex.lex()

#Debug para cuando las reglas no funcionan bien D:
#Entrada
##lex.input("print (kovamasmas);")

#Uso de los tokens (imprimiendo por lo pronto)
##while True:
##    tok = lex.token()
##    if not tok:
##        break
##    else:
##        print tok.type

#Inicializacion del Parser
yacc.yacc()

nombreArchivo = raw_input("Nombre del Archivo: ")

archivo = open(nombreArchivo, 'r')

datos = archivo.read()

yacc.parse(datos)